# KnowYourBite

A fully deployable React + Node.js calorie tracker.

## Features
- Upload food images
- Auto food detection
- Admin panel to add foods
- Meal history tracking
- Total daily calories
- Tailwind CSS styling
- Backend API for storing food database

## Deploy
- Frontend: Vercel
- Backend: Render / Railway / Heroku