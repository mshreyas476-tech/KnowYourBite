const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get("/api/foods", (req, res) => {
  const dbPath = path.join(__dirname, "foodDatabase.json");
  const data = JSON.parse(fs.readFileSync(dbPath));
  res.json(data);
});

app.post("/api/foods", (req, res) => {
  const { name, weight, calories } = req.body;
  if (!name || !weight || !calories) return res.status(400).json({ message: "Invalid input" });
  const dbPath = path.join(__dirname, "foodDatabase.json");
  const data = JSON.parse(fs.readFileSync(dbPath));
  data[name.toLowerCase()] = { weight, calories };
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  res.json({ message: `${name} added!` });
});

app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));